#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include<sys/types.h>
#include<sys/timeb.h>
#include"sat.h"
#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASTABLE -1
#define OVERFLOW -2


void print(int** board) {
	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 6; j++) {
			if (board[i][j] >= 0)
				printf("[%d ]", board[i][j]);
			else printf("[  ]");
		}
		printf("\n");
	}
}

int Testrule(int** board) {
	int i = 0, j = 0, k = 0;
	int num_0 = 0, num_1 = 0;
	int count = 0;
	for (i = 0; i < 6; i++) {//�����
		for (j = 0; j < 6; j++) {
			if (board[i][j] == 1) {
				num_1++;
			}
			if (board[i][j] == 0) {
				num_0++;
			}
		}
		if (num_1 >= 4 || num_0 >= 4) return FALSE;
		num_0 = num_1 = 0;
	}
	for (i = 0; i < 6; i++) {//�����
		for (j = 0; j < 6; j++) {
			if (board[j][i] == 1) {
				num_1++;
			}
			if (board[j][i] == 0) {
				num_0++;
			}
		}
		if (num_1 >= 4 || num_0 >= 4) return FALSE;
		num_0 = num_1 = 0;
	}



	for (i = 0; i < 6; i++) {//����һ
		for (j = 1; j < 5; j++) {
			if ((board[i][j - 1] == board[i][j]) && (board[i][j] == board[i][j + 1]) && (board[i][j] != -1)) return FALSE;
		}
	}
	for (j = 0; j < 6; j++) {//����һ
		for (i = 1; i < 5; i++) {
			if ((board[i - 1][j] == board[i][j]) && (board[i][j] == board[i + 1][j]) && (board[i][j] != -1)) return FALSE;
		}
	}

	k = 0;//������
	for (i = 0; i < 5; i++) {
		for (j = i + 1; j < 6; j++) {
			while (k < 6) {
				if (board[i][k] == board[j][k] && board[i][k] != -1) count++;
				k++;
			}
			if (count == 6) return FALSE;
			count = 0;
			k = 0;
		}
	}
	for (j = 0; j < 5; j++) {
		for (i = j + 1; i < 6; i++) {
			while (k < 6) {
				if (board[k][j] == board[k][i] && board[k][j] != -1) count++;
				k++;
			}
			if (count == 6) return FALSE;
			count = 0;
			k = 0;
		}
	}
	return OK;
}

int ALLboard(int** board) {
	int count = 0;
	int stack[36] = { 0 };
	int flag[36] = { 0 };
	int top = 0;
	int a = 0, i, j, value = 1;
	unsigned int seedVal;
	struct timeb timeBuf;
	ftime(&timeBuf);
	seedVal = ((((unsigned int)timeBuf.time & 0xFFFF) +
		(unsigned int)timeBuf.millitm) ^
		(unsigned int)timeBuf.millitm);
	srand((unsigned int)seedVal);
	a = rand() % 36;
	while (count < 36) {
		if (value) {
			while (flag[a] != 0) {
				a = rand() % 36;
			}
		}
		i = a / 6, j = a % 6;
		board[i][j] = 1;
		flag[a]++;
		if (!Testrule(board)) {
			board[i][j] = 0;
			flag[a]++;
			if (!Testrule(board)) {
				board[i][j] = -1;
				flag[a] = 0;
				a = stack[top - 1];
				top--;
				count--;
				while (flag[a] == 2) {
					flag[a] = 0;
					i = a / 6, j = a % 6;
					board[i][j] = -1;
					a = stack[top - 1];
					top--;
					count--;
				}
				value = 0;
			}
			else {
				stack[top++] = a;
				count++;
				value = 1;
			}
		}
		else {
			stack[top++] = a;
			count++;
			value = 1;
		}
	}
	return OK;
}


void Canju(SqList& Ans) {
	for (int i = 1; i < Ans.length; i++) {
		if (Ans.elem[i] > 0) printf("[%d]", Ans.elem[i]);
		else if (Ans.elem[i] == 0)printf("[0]");
		else printf("[ ]");
		if (i % 6 == 0) printf("\n");
	}
}