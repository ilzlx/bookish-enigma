#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include<sys/types.h>
#include<sys/timeb.h>

#define TRUE 1
#define FALSE 0
#define OK 1
#define ERROR 0
#define INFEASTABLE -1
#define OVERFLOW -2

typedef struct LNode {
	int num;          //����
	int mark;         //����ֵ
	struct LNode* next;//��һ��Ԫ
}LNode, * pLNode;

typedef struct CNode {
	int L_num;		  //��Ԫ��
	int flag;		  //����Ƿ���Ϊx��ɾ�� ֵȡ 0��MAX
	int mark;         //����Ƿ�ɾ�� ֵȡ0 1
	LNode* firstL;
	struct CNode* next;	  //��һ�Ӿ�
}CNode, * pCNode;

typedef struct INode {
	CNode* p_cnode;       //�洢ָ�������ͷ����ָ�� 
	struct INode* next;
}INode, * pINode;       //���������ڽӵ� 

typedef struct Index {
	INode* firstT;       //��ֵ�������� 
	INode* firstF;       //��ֵ�������� 
} Index, * pIndex;//�����������Ķ��� 
typedef struct CNF {
	int varnum;       //��Ԫ��
	int clanum;		  //�Ӿ���
	CNode* firstC;      //ָ���һ���Ӿ�ڵ� 
	Index* Index_List;    //������ 
}CNF, * pCNF;

typedef struct SqList {
	int* elem;
	int length;
}SqList;
int CreateCNF(pCNF* L, char filename[100]) {
	pLNode q;    //���ֽڵ�
	pCNode p;    //�Ӿ�ͷ���
	pINode s;    //�������ڵ�
	int i;
	int num = 0;
	int x = 0;              //��¼ÿ���Ӿ��Ԫ���� 
	int y = 0;             //��¼�Ӿ�ĸ��� 
	int flag;         //��¼���� 
	char c;
	*L = (CNF*)malloc(sizeof(CNF));
	p = (CNode*)malloc(sizeof(CNode));
	p->mark = 1;
	p->flag = 0;
	(*L)->firstC = p;
	FILE* fp;
	if ((fp = fopen(filename, "r")) == NULL) {
		printf("�ļ���ʧ�ܣ�\n");
		return ERROR;
	}
	fscanf(fp, "%c", &c);
	if (c != 'c'&&c!='p') return FALSE;
	while (!(feof(fp))) {
		if (c == 'c')//����ע�� 
		{
			while (c != '\n') {
				fscanf(fp, "%c", &c);
			}
			fscanf(fp, "%c", &c);
		}
		else if (c == 'p') {
			while (c != '\n') {
				while (c > '9' || c < '0') {
					fscanf(fp, "%c", &c);
				}
				while (c <= '9' && c >= '0')//���ȶ�ȡ��Ԫ��
				{
					num = num * 10 + c - '0';
					fscanf(fp, "%c", &c);
				}
				(*L)->varnum = num;
				(*L)->Index_List = (Index*)malloc(sizeof(Index) * (num + 1));
				for (i = 0; i <= num; i++) {
					(*L)->Index_List[i].firstT = NULL;
					(*L)->Index_List[i].firstF = NULL;
				}
				fscanf(fp, "%c", &c);
				num = 0;
				while (c <= '9' && c >= '0') {
					num = num * 10 + c - '0';
					fscanf(fp, "%c", &c);
				}
				(*L)->clanum = num;
			}
			fscanf(fp, "%c", &c);
		}
		else if ((c <= '9' && c >= '0') || c == '-') {
			q = (LNode*)malloc(sizeof(LNode));
			q->mark = 1;
			p->firstL = q;
			while ((c != '\n') && (!(feof(fp)))) {
				while ((c != '0') && (!(feof(fp)))) {
					while (c != ' ') {
						s = (INode*)malloc(sizeof(INode));
						s->p_cnode = p;
						if (c == '-') {
							num = 0;
							flag = 0;
							fscanf(fp, "%c", &c);
							while (c <= '9' && c >= '0') {
								num = num * 10 + c - '0';
								fscanf(fp, "%c", &c);
							}
							q->num = -num;
							s->next = (*L)->Index_List[num].firstF;
							(*L)->Index_List[num].firstF = s;
						}
						else {
							num = 0;
							flag = 1;
							while (c <= '9' && c >= '0') {
								num = num * 10 + c - '0';
								fscanf(fp, "%c", &c);
							}
							q->num = num;
							s->next = (*L)->Index_List[num].firstT;
							(*L)->Index_List[num].firstT = s;
						}
						x++;
					}
					fscanf(fp, "%c", &c);
					if (c == '0') q->next = NULL;
					else {
						q->next = (LNode*)malloc(sizeof(LNode));
						q = q->next;
						q->mark = 1;
					}
				}
				fscanf(fp, "%c", &c);
			}
			p->L_num = x;
			x = 0;
			y++;
			fscanf(fp, "%c", &c);
			if ((*L)->clanum > y) {
				p->next = (CNode*)malloc(sizeof(CNode));
				p = p->next;
				p->flag = 0;
				p->mark = 1;
			}
			else p->next = NULL;
		}
		else fscanf(fp, "%c", &c);//�Ե����໻��
	}
	if ((*L)->varnum == 0)  return FALSE;
	fclose(fp);
	return OK;
}

int PrintCNF(pCNF L) {
	if (!L->clanum) {
		printf("CNF��ʽ������!\n");
		return OK;
	}
	pCNode p = L->firstC;
	pLNode q;
	printf("CNF��ʽ:  ��Ԫ��:%d  �Ӿ���:%d\n", L->varnum, L->clanum);
	while (p) {
		q = p->firstL;
		while (q) {
			printf("%d", q->num);
			q = q->next;
			if (q) printf("��");
		}
		printf("\n");
		p = p->next;
	}
	return OK;
}

int InitList(pCNF L, SqList& Ans) {//Ϊ�洢�𰸵�˳�������洢�ռ� 
	Ans.elem = (int*)malloc(sizeof(int) * (L->varnum + 1));//����洢�ռ� 
	if (!Ans.elem) {
		return ERROR;//����洢�ռ�ʧ�� 
	};
	Ans.length = L->varnum + 1;//��ʼ�����Ա��ĳ���Ϊ0 
	for (int i = 1; i < Ans.length; i++) {
		Ans.elem[i] = 0;                        //��ʾ��Ԫû�н��м򻯸�ֵ��ȡֵ����  
	}
	return OK;
}

int EmptyClause(pCNF L) {        //�鿴�Ƿ��пվ� 
	pCNode p = L->firstC;
	while (p) {
		if (p->L_num == 0 && p->mark == 1) return OK;
		p = p->next;
	}
	return FALSE;
}

int RemoveClause(pCNF L, int var) {//���Ӿ䣬�������Ԫɾ��ϵ���Ӿ�
	pCNode p;    //�Ӿ�ͷ��� 
	pLNode q;    //���ֽڵ�
	pINode s;    //�������ڵ�
	if (var > 0) {    //���Ӿ�
		s = L->Index_List[var].firstT;//����ɾ����Ӧ�Ӿ�
		while (s) {
			if (s->p_cnode->mark == 0) s = s->next;//������ɾ���Ӿ�
			else {
				s->p_cnode->mark = 0;
				s->p_cnode->flag = var;
				s = s->next;
				L->clanum--;
			}
		}
		s = L->Index_List[var].firstF;					//����ɾ����Ӧ�ķ���Ԫ
		while (s) {
			if (s->p_cnode->mark == 0)  s = s->next;
			else {
				q = s->p_cnode->firstL;
				while (q) {
					if (q->num == (-var) && q->mark == 1) {
						q->mark = 0;
						s->p_cnode->L_num--;
					}
					q = q->next;
				}
				s = s->next;
			}
		}
	}
	else {   //���Ӿ�
		s = L->Index_List[-var].firstF;//����ɾ����Ӧ�Ӿ�
		while (s) {
			if (s->p_cnode->mark == 0) s = s->next;//������ɾ���Ӿ�
			else {
				s->p_cnode->mark = 0;
				s->p_cnode->flag = var;
				s = s->next;
				L->clanum--;
			}
		}
		s = L->Index_List[-var].firstT;					//����ɾ����Ӧ�ķ���Ԫ
		while (s) {
			if (s->p_cnode->mark == 0)  s = s->next;
			else {
				q = s->p_cnode->firstL;
				while (q) {
					if (q->num == (-var) && q->mark == 1) {
						q->mark = 0;
						s->p_cnode->L_num--;
					}
					q = q->next;
				}
				s = s->next;
			}
		}
	}
	L->varnum--;
	return OK;
}

int AddClause(pCNF L, int var) {
	pCNode p;    //�Ӿ�ͷ��� 
	pLNode q;    //���ֽڵ�
	pINode s;    //�������ڵ�
	if (var > 0) {
		s = L->Index_List[var].firstT;
		while (s) {
			if (s->p_cnode->mark == 1) s = s->next;
			else {
				if (s->p_cnode->flag == var) {
					s->p_cnode->flag = 0;
					s->p_cnode->mark = 1;
					s = s->next;
					L->clanum++;
				}
				else s = s->next;
			}
		}
		s = L->Index_List[var].firstF;
		while (s) {
			q = s->p_cnode->firstL;
			while (q) {
				if (q->mark == 1) q = q->next;
				else {
					if (q->mark == 0 && q->num == (-var)) {
						q->mark = 1;
						s->p_cnode->L_num++;
					}
					q = q->next;
				}
			}
			s = s->next;
		}
	}
	else {
		s = L->Index_List[-var].firstF;
		while (s) {
			if (s->p_cnode->mark == 1) s = s->next;
			else {
				if (s->p_cnode->flag == var) {
					s->p_cnode->flag = 0;
					s->p_cnode->mark = 1;
					s = s->next;
					L->clanum++;
				}
				else s = s->next;
			}
		}
		s = L->Index_List[-var].firstT;
		while (s) {
			q = s->p_cnode->firstL;
			while (q) {
				if (q->mark == 1) q = q->next;
				else {
					if (q->mark == 0 && q->num == (-var)) {
						q->mark = 1;
						s->p_cnode->L_num++;
					}
					q = q->next;
				}
			}
			s = s->next;
		}
	}
	L->varnum++;
	return OK;
}

int SearchVar(pCNF L, SqList& Ans) {
	pCNode p;
	pLNode q;
	p = L->firstC;
	while (p) {//Ѱ�ҵ��Ӿ�
		if (p->mark == 1 && p->L_num == 1) {
			q = p->firstL;
			while (q) {
				if (q->mark == 1) {
					if (q->num > 0) Ans.elem[q->num] = 1;//����һ��ʾ����ֵѡ��
					else Ans.elem[-(q->num)] = -1;
					return q->num;  //��ʱ�ҵ����Ӿ��б�Ԫ
				}
				q = q->next;
			}
		}
		p = p->next;
	}
	//Ѱ�Һ��ʱ�Ԫ
	int i;
	int flag = 0;
	int* fre = (int*)malloc(sizeof(int) * (2 * Ans.length - 1));
	for (i = 0; i < 2 * Ans.length - 1; i++) {
		fre[i] = 0;
	}
	p = L->firstC;
	while (p) {                //��¼����Ԫ���ֵĴ��� 
		if (p->mark == 0) p = p->next;
		else {
			q = p->firstL;
			while (q) {
				if (q->mark == 0) q = q->next;
				else {
					if (q->num > 0) fre[2 * (q->num) - 1]++;
					else if (q->num < 0)    fre[2 * (-(q->num))]++;
					q = q->next;
				}
			}
			p = p->next;
		}
	}
	for (i = 1; i < 2 * Ans.length - 1; i++) {    //�ҳ����ִ��������ֵ 
		if (fre[i] > flag)  flag = fre[i];
	}
	for (i = 1; i < 2 * Ans.length - 1; i++) {  //�ҵ���Ԫ 
		if (fre[i] == flag)  break;
	}
	free(fre);
	if (i % 2) {
		Ans.elem[(i + 1) / 2] = 1;
		return ((i + 1) / 2);
	}
	else {
		Ans.elem[i / 2] = -1;
		return (-(i / 2));
	}
}

int DPLL(pCNF L, SqList& Ans, int var_1) {
	int var_2;
	if (L->clanum == 0) return OK; //�������
	else {
		if (EmptyClause(L) == OK) {//�������Ӿ�����
			if (!AddClause(L, var_1)) printf("��������޷������Ŀ��Ӿ䣬��ԭʧ�ܣ�");
			if (var_1 > 0) Ans.elem[var_1] = 0; //�ñ�Ԫ���������cnf��ʽ����������Ϊ0
			else Ans.elem[-var_1] = 0;
			return ERROR;
		}
		else {
			var_2 = SearchVar(L, Ans);
			if (var_2 == 0)return ERROR;
			if (!RemoveClause(L, var_2)) printf("������Ԫ%dʧ�ܣ�", var_2);
			if (DPLL(L, Ans, var_2)) return OK;
			else {
				if (!AddClause(L, var_2)) printf("�ָ���Ԫ%dʧ�ܣ�", var_2);
				if (!RemoveClause(L, -var_2)) printf("������Ԫ%dʧ��", -var_2);
				if (DPLL(L, Ans, -var_2)) {//��ʱ����ֵ��ת
					if (var_2 > 0) Ans.elem[var_2] = -1;
					else Ans.elem[-var_2] = 1;
					return OK;
				}
				else {
					if (!AddClause(L, -var_2)) printf("�ָ���Ԫ%dʧ�ܣ�", -var_2);
					if (var_2 > 0) Ans.elem[var_2] = 0;
					else Ans.elem[-var_2] = 0;
					return ERROR;
				}
			}
		}
	}

}

int Test(pCNF L, SqList& Ans) {
	int flag;
	pCNode p;
	pLNode q;
	p = L->firstC;
	while (p) {
		flag = 0;
		q = p->firstL;
		while (q) {
			if (((q->num > 0) && (Ans.elem[q->num] == 1)) || ((q->num < 0) && (Ans.elem[-(q->num)] == -1))) {
				flag = 1;
				break;
			}
			else q = q->next;
		}
		if (flag == 0) break;
		p = p->next;
	}
	if (flag == 0)  return FALSE;
	else return TRUE;
}

int rule_1(char filename[100]) {
	FILE* fp;
	fp = fopen(filename, "a+");
	if (!fp) {
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}
	int i, j, k;
	for (i = 0; i < 6; i++) {//�й���
		for (j = 1; j <= 4; j++) {
			for (k = 0; k <= 2; k++) {
				fprintf(fp, "%d ", i * 6 + j + k);
			}
			fprintf(fp, "0\n");
			for (k = 0; k <= 2; k++) {
				fprintf(fp, "%d ", -(i * 6 + j + k));
			}
			fprintf(fp, "0\n");
		}
	}
	for (i = 1; i <= 6; i++) {//�й���
		for (j = 1; j <= 4; j++) {
			for (k = 0; k <= 2; k++) {
				fprintf(fp, "%d ", i + (j - 1) * 6 + k * 6);
			}
			fprintf(fp, "0\n");
			for (k = 0; k <= 2; k++) {
				fprintf(fp, "%d ", -(i + (j - 1) * 6 + k * 6));
			}
			fprintf(fp, "0\n");
		}
	}
	fclose(fp);
	return OK;
}

int rule_2(char filename[100]) {
	FILE* fp;
	fp = fopen(filename, "a+");
	if (!fp) {
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}
	int m, n, i, j, k;
	for (k = 0; k < 6; k++) {//�й���
		for (m = 1; m <= 3; m++) {
			for (n = 2; n <= 4; n++) {
				for (i = 3; i <= 5; i++) {
					for (j = 4; j <= 6; j++) {
						if (m < n && n < i && i < j) {
							fprintf(fp, "%d %d %d %d 0\n", m + 6 * k, n + 6 * k, i + 6 * k, j + 6 * k);
							fprintf(fp, "%d %d %d %d 0\n", -(m + 6 * k), -(n + 6 * k), -(i + 6 * k), -(j + 6 * k));
						}
					}
				}
			}
		}
	}
	for (k = 0; k < 6; k++) {//�й���
		for (m = 1; m <= 13; m += 6) {
			for (n = 7; n <= 19; n += 6) {
				for (i = 13; i <= 25; i += 6) {
					for (j = 19; j <= 31; j += 6) {
						if (m < n && n < i && i < j) {
							fprintf(fp, "%d %d %d %d 0\n", m + k, n + k, i + k, j + k);
							fprintf(fp, "%d %d %d %d 0\n", -(m + k), -(n + k), -(i + k), -(j + k));
						}
					}
				}
			}
		}
	}
	fclose(fp);
	return OK;
}

int rule_3(char filename[100]) {
	FILE* fp;
	fp = fopen(filename, "a+");
	if (!fp) {
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}
	int x, y, i, j, k, m, n;
	int cout = 0;
	int num = 0;
	int a = 0, b = 0, c = 0, d = 0;
	//�ȴ�����
	for (x = 0; x < 5; x++)//��ֵȫ����ȫ��
	{
		for (y = x + 1; y < 6; y++) {
			for (i = 1; i <= 6; i++) {
				fprintf(fp, "%d %d ", i + x * 6, i + y * 6);
			}
			fprintf(fp, "0\n");
			cout++;
			for (i = 1; i <= 6; i++) {
				fprintf(fp, "%d %d ", -(i + x * 6), -(i + y * 6));
			}
			fprintf(fp, "0\n");
			cout++;
		}
	}
	for (x = 0; x < 5; x++) //��һ��Ϊ�����һ��Ϊ��
	{
		for (y = x + 1; y < 6; y++) {
			for (i = 1; i <= 6; i++) {
				for (j = 1; j <= 6; j++) {
					if (j == i)fprintf(fp, "%d %d ", -(j + x * 6), -(j + y * 6));
					else fprintf(fp, "%d %d ", j + x * 6, j + y * 6);
				}
				fprintf(fp, "0\n");
				cout++;
				for (j = 1; j <= 6; j++) {
					if (j == i)fprintf(fp, "%d %d ", j + x * 6, j + y * 6);
					else fprintf(fp, "%d %d ", -(j + x * 6), -(j + y * 6));
				}
				fprintf(fp, "0\n");
				cout++;
			}
		}
	}
	for (x = 0; x < 5; x++) //������Ϊ���������Ϊ��
	{
		for (y = x + 1; y < 6; y++) {
			for (i = 1; i <= 5; i++) {
				for (j = i + 1; j <= 6; j++) {
					for (k = 1; k <= 6; k++) {
						if (k == i || k == j) fprintf(fp, "%d %d ", -(k + x * 6), -(k + y * 6));
						else fprintf(fp, "%d %d ", (k + x * 6), (k + y * 6));
					}
					fprintf(fp, "0\n");
					cout++;
					for (k = 1; k <= 6; k++) {
						if (k == i || k == j) fprintf(fp, "%d %d ", (k + x * 6), (k + y * 6));
						else fprintf(fp, "%d %d ", -(k + x * 6), -(k + y * 6));
					}
					fprintf(fp, "0\n");
					cout++;
				}
			}
		}
	}
	for (x = 0; x < 5; x++) //������Ϊ���������Ϊ��
	{
		for (y = x + 1; y < 6; y++) {
			for (i = 1; i <= 4; i++) {
				for (j = i + 1; j <= 5; j++) {
					for (k = j + 1; k <= 6; k++) {
						for (m = 1; m <= 6; m++) {
							if (m == i || m == j || m == k) fprintf(fp, "%d %d ", -(m + x * 6), -(m + y * 6));
							else fprintf(fp, "%d %d ", (m + x * 6), (m + y * 6));
						}
						fprintf(fp, "0\n");
						cout++;
					}
				}
			}
		}
	}

	//������
	for (x = 1; x <= 5; x++) //��ֵȫ���ȫ��
	{
		for (y = x + 1; y <= 6; y++) {
			for (i = 0; i < 6; i++) {
				fprintf(fp, "%d %d ", x + 6 * i, y + 6 * i);
			}
			fprintf(fp, "0\n");
			a++;
			for (i = 0; i < 6; i++) {
				fprintf(fp, "%d %d ", -(x + 6 * i), -(y + 6 * i));
			}
			fprintf(fp, "0\n");
			a++;
		}
	}

	for (i = 1; i <= 6; i++) //��һ��Ϊ�����һ��Ϊ��
	{
		for (x = 1; x <= 5; x++) {
			for (y = x + 1; y <= 6; y++) {
				for (j = 0; j < 6; j++) {
					if (x == i) fprintf(fp, "%d %d ", -(x + 6 * j), -(y + 6 * j));
					else fprintf(fp, "%d %d ", (x + 6 * j), (y + 6 * j));
				}
				fprintf(fp, "0\n");
				b++;
				for (j = 0; j < 6; j++) {
					if (x == i) fprintf(fp, "%d %d ", -(x + 6 * j), -(y + 6 * j));
					else fprintf(fp, "%d %d ", (x + 6 * j), (y + 6 * j));
				}
				fprintf(fp, "0\n");
				b++;
			}
		}
	}

	for (i = 1; i <= 5; i++) //������Ϊ���������Ϊ��
	{
		for (j = i + 1; j <= 6; j++) {
			for (x = 1; x <= 5; x++) {
				for (y = x + 1; y <= 6; y++) {
					for (k = 0; k < 6; k++) {
						if (x == i || x == j) fprintf(fp, "%d %d ", -(x + 6 * k), -(y + 6 * k));
						else fprintf(fp, "%d %d ", (x + 6 * k), (y + 6 * k));
					}
					fprintf(fp, "0\n");
					c++;
					for (k = 0; k < 6; k++) {
						if (x == i || x == j) fprintf(fp, "%d %d ", (x + 6 * k), (y + 6 * k));
						else fprintf(fp, "%d %d ", -(x + 6 * k), -(y + 6 * k));
					}
					fprintf(fp, "0\n");
					c++;
				}
			}
		}
	}

	for (i = 1; i <= 4; i++) //������Ϊ���������Ϊ��
	{
		for (j = i + 1; j <= 5; j++) {
			for (k = j + 1; k <= 6; k++) {
				for (x = 1; x <= 5; x++) {
					for (y = x + 1; y <= 6; y++) {
						for (n = 0; n < 6; n++) {
							if (x == i || x == j || x == k) fprintf(fp, "%d %d ", -(x + 6 * n), -(y + 6 * n));
							else fprintf(fp, "%d %d ", (x + 6 * n), (y + 6 * n));
						}
						fprintf(fp, "0\n");
						d++;
					}
				}
			}
		}
	}

	fclose(fp);
	return OK;
}

int Createborad(int** board, char filename[100]) {
	int i, j, count = 0;

	FILE* fp;
	fp = fopen(filename, "w");
	if (fp == NULL) {
		printf("���ļ�ʧ��\n");
		return ERROR;
	}
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if (board[i][j] == 1 || board[i][j] == 0) count++;
		}
	}
	fprintf(fp, "c Binary_Puzzle\n");
	fprintf(fp, "p cnf 36 %d\n", count + 2376);
	i = 0;
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			if (board[i][j] == 1) fprintf(fp, "%d 0\n", (i * 6 + j + 1));
			else if (board[i][j] == 0) fprintf(fp, "%d 0\n", -(i * 6 + j + 1));
		}
	}
	fclose(fp);
	if (rule_1(filename) != OK) return FALSE;
	if (rule_2(filename) != OK) return FALSE;
	if (rule_3(filename) != OK) return FALSE;
	return OK;
}

int ResWrite_1(int res, double time, SqList& Ans, char filename[100]) {       //�������д���ļ� 
	int i = 0;
	while (filename[i] != '\0') i++;
	filename[i - 3] = 'r';    //ֻ�ı��ļ�����չ�� 
	filename[i - 2] = 'e';
	filename[i - 1] = 's';
	FILE* fp;
	fp = fopen(filename, "w");
	if (fp == NULL) {
		printf("���ļ�ʧ��\n");
		return ERROR;
	}
	fprintf(fp, "s %d\n", res);    //res���������1��ʾ���㣬0��ʾ�����㣬-1δ��
	fprintf(fp, "v \n");
	for (i = 1; i < Ans.length; i++) {
		if (Ans.elem[i] == -1)  fprintf(fp, "%5d", -i);
		else fprintf(fp, "%5d", i);
		if (i % 10 == 0)  fprintf(fp, "\n");
	}
	fprintf(fp, "\nt %f ms\n", time);
	fclose(fp);
	return OK;
}

int ResWrite_2(int res, double time, SqList& Ans, char filename[100]) {       //�������д���ļ� 
	int i = 0, j;
	while (filename[i] != '\0') i++;
	filename[i - 3] = 'r';    //ֻ�ı��ļ�����չ�� 
	filename[i - 2] = 'e';
	filename[i - 1] = 's';
	FILE* fp;
	fp = fopen(filename, "w");
	if (fp == NULL) {
		printf("���ļ�ʧ��\n");
		return ERROR;
	}
	fprintf(fp, "s %d\n", res);    //res���������1��ʾ���㣬0��ʾ�����㣬-1δ��
	fprintf(fp, "v \n");
	fprintf(fp, "----------------------------\n");
	for (i = 1; i < 37; i++) {
		if (Ans.elem[i] > 0) fprintf(fp, " %d ", Ans.elem[i]);
		else fprintf(fp, " 0 ");
		if (i % 6 == 0) fprintf(fp, "\n");
	}
	fprintf(fp, "----------------------------\n");
	fprintf(fp, "\nt %f ms\n", time);
	fclose(fp);
	return OK;
}

int sat(SqList& Ans, pCNF* L, char filename[100], int** board) {
	Createborad(board, filename);
	CreateCNF(L, filename);
	InitList(*L, Ans);
	if (DPLL(*L, Ans, 1)) return OK;
	else return ERROR;
}

int DigSudoku(int** board, int yunju[6][6], char filename[100], SqList& Ans, pCNF* L, int n) {
	int count = 0;
	clock_t start, end;
	int stack[36] = { 0 };
	int f_num[36] = { 0 };
	int flag[36][36] = { 0 };
	int top = 0;
	int a = 0, i, j, s_num = 36, d_num = 0;
	int level[5] = { 24,25,26,27,28 };
	unsigned int seedVal;
	struct timeb timeBuf;
	ftime(&timeBuf);
	seedVal = ((((unsigned int)timeBuf.time & 0xFFFF) +
		(unsigned int)timeBuf.millitm) ^
		(unsigned int)timeBuf.millitm);
	srand((unsigned int)seedVal);
	a = rand() % 36;
	i = a / 6, j = a % 6;
	board[i][j] = -1;
	stack[top++] = a;
	s_num--, d_num++;
	a = rand() % 36, i = a / 6, j = a % 6;
	start = clock();
	double time;
	while (d_num < level[n - 1]) {
		while (f_num[a] >= s_num) {
			f_num[a] = 0;
			i = a / 6, j = a % 6;
			board[i][j] = yunju[i][j];
			for (i = 0; i < 36; i++) {
				flag[a][i] = 0;
			}
			a = stack[top - 1], top--;
			s_num++, d_num--;
		}
		while (board[i][j] == -1 || flag[stack[top - 1]][a] > 0) {
			a = rand() % 36;
			i = a / 6, j = a % 6;
		}
		if (board[i][j])board[i][j] = 0;
		else board[i][j] = 1;
		if (!sat(Ans, L, filename, board)) {
			f_num[stack[top - 1]]++;
			flag[stack[top - 1]][a]++;
			s_num--, d_num++;
			board[i][j] = -1;
			stack[top++] = a;
		}
		else {
			board[i][j] = yunju[i][j];
			f_num[stack[top - 1]]++;
			flag[stack[top - 1]][a]++;
		}
		a = rand() % 36, i = a / 6, j = a % 6;
		end = clock();
		time = ((double)(end - start)) / CLK_TCK;
		if (time > 10) return FALSE;
	}
	for (i = 0; i < 6; i++) {
		for (j = 0; j < 6; j++) {
			Ans.elem[i * 6 + j + 1] = board[i][j];
		}
	}
	return OK;
}